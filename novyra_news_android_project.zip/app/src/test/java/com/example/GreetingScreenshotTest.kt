package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.components.TopHeader
import com.example.ui.theme.NovyraNewsTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun app_header_screenshot() {
        composeTestRule.setContent {
            NovyraNewsTheme {
                TopHeader(
                    country = "India",
                    state = "West Bengal",
                    city = "Kolkata",
                    currentLanguageCode = "en",
                    isDarkMode = false,
                    onLocationClick = {},
                    onLanguageClick = {},
                    onSearchClick = {},
                    onAdminClick = {},
                    onThemeToggle = {}
                )
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/header.png")
    }
}
